import React from 'react';

//generamos nuestra funcion para realizar el despliegue

function Hola() {
    return(
        <h1>Hola a todos los de la clase</h1>
    )
}

export default Hola
