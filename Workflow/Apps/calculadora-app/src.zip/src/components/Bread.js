import React from 'react';

//generamos nuestra funcion para realizar el despliegue

function Bread() {
    return(
        <h1>Ruta de acceso</h1>
    )
}

export default Bread