import react from 'react'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
import Welcome from './Page/Welcome'
import MainPage from './Page/MainPage'
import CityPage from './Page/CityPage'
import PageNotFound from './Page/PageNotFound'

import { Grid } from '@material-ui/core'

function App() {
  return (
    <div className="App">
      

      <Grid container justify='center' direction='row'>
        <Grid item sm={12} md={8} >
        <Router>
          <Switch>
            <Route exact path='/'>
              <Welcome />
            </Route>

            <Route path='/main'>
              {/* <h1>que pedo ?</h1> */}
              <MainPage />
            </Route>

            <Route path='/city'>
              <CityPage />
            </Route>

            <Route path=''>
              <PageNotFound />
            </Route>

          </Switch>
        </Router>
        </Grid>
      </Grid>

    </div >
  );
}

export default App;
