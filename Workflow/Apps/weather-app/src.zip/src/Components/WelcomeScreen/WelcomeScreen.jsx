import React, { useRef, useEffect, useState } from 'react'
import PropTypes from 'prop-types'
import Clouds from 'vanta/dist/vanta.clouds.min'
import * as THREE from 'three'


const WelcomeScreen = props => {
    const { children } = props

    const myRefDiv = useRef(null)
    const [vanta, setVanta] = useState(0)
    useEffect(() => {
        console.log("Primera renderizacion del useRef", myRefDiv.current)
        if (vanta === 0) {
            setVanta(
                Clouds({
                    THREE,
                    el: myRefDiv.current
                })
            )
        }
        
    }, [vanta]);


    return (
        <div ref={myRefDiv}>
            {children}
        </div>
    )
}

WelcomeScreen.stories.propTypes = {
    children: PropTypes.node
}

export default WelcomeScreen
