import React from 'react'
import PropTypes from 'prop-types'
import { Grid, AppBar, Toolbar, IconButton, Link, Typography } from '@material-ui/core'
import { IconContext } from 'react-icons'
import { WiDayCloudy } from 'react-icons/wi'
import { Link as LinkRouter } from 'react-router-dom'

const AppFrame = props => {
    const { children } = props
    return (
        <Grid container justify="center">
            <AppBar position="sticky">
                <Toolbar variant="dense">
                    <IconButton color="inherit" aria-label="menu">
                        <Link
                            to="/main"
                            color="inherit"
                            aria-label="menu"
                            component={LinkRouter}
                        >
                            <IconContext.Provider value={{ size: '2em' }}>
                                <WiDayCloudy />
                            </IconContext.Provider>
                        </Link>
                    </IconButton>
                    <Typography color="inherit" variant="h6">
                        Aplicacion del clima
                    </Typography>
                </Toolbar>
            </AppBar>
            <Grid container item
                xs={12}
                sm={11}
                md={10}
                lg={8}
            >
                {/* aqui deberia de ir el children con la aplicacion */}
                {/* Aqui esta mi app */}
            </Grid>
        </Grid>
    )
}

AppFrame.propTypes = {
    children: PropTypes.node
}

export default AppFrame
