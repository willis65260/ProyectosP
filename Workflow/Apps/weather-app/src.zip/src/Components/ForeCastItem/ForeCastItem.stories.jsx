import React from 'react'
import ForeCastItem from './ForeCastItem'

export default {
    title: "ForeCastItem",
    component: ForeCastItem
}

export const ForeCastItemExample = () =>
<ForeCastItem
        weekDay="Viernes"
        hour={10}
        state="rainy"
        temperature="19"
    />
