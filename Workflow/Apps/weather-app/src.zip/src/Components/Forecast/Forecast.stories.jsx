import React, { Component } from 'react';
import Forecast from './Forecast'

export default {
    title: "Forecast",
    Component: Forecast
}

const forecastItemList = [
    { weekDay: "Lunes", hour: 18, state: "sunny", temperature: 17 },
    { weekDay: "Martes", hour: 18, state: "cloud", temperature: 17 },
    { weekDay: "Miercoles", hour: 18, state: "cloudy", temperature: 17 },
    { weekDay: "Jueves", hour: 18, state: "rainy", temperature: 17 },
    { weekDay: "Viernes", hour: 18, state: "sunny", temperature: 17 },
    { weekDay: "Sabado", hour: 18, state: "cloud", temperature: 17 },
    { weekDay: "Domingo", hour: 18, state: "rainy", temperature: 17 }
]

export const ForecastExample = () => <Forecast forecastItemList={forecastItemList} />