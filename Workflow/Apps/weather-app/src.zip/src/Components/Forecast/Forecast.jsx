import React from 'react'
import PropTypes from 'prop-types'
import Grid from '@material-ui/core/Grid'
import ForeCastItem from '../ForeCastItem/ForeCastItem'

const renderForecastItem = forecast => {
    const { weekDay, hour, state, temperature } = forecast
    return (
        <Grid item key={`${weekDay}${hour}`}>
            <ForeCastItem weekDay={weekDay} hour={hour} state={state} temperature={temperature} />
        </Grid>
    )
}
const Forecast = props => {
    const { forecastItemList } = props
    return (
        <Grid container justify="space-around" alignItems="center">{
            forecastItemList.map(forecast => renderForecastItem(forecast))
        }</Grid>
    )
}

Forecast.propTypes = {
    forecastItemList: PropTypes.arrayOf(
        PropTypes.shape({
            weekDay: PropTypes.string.isRequired,
            hour: PropTypes.number.isRequired,
            state: PropTypes.string.isRequired,
            temperature: PropTypes.number.isRequired
        })
    )
}

export default Forecast
