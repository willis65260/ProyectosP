import { CardActions } from '@material-ui/core';
import React from 'react';
import CityList from './CityList'

export default {
    title: "CityList",
    component: CityList
}

const cities = [{
    city: "CD de Mexico",
    country: "Mexico "
}, {
    city: "Bogota",
    country: "Colombia "
}, {
    city: "Madrid",
    country: "España "
}, {
    city: "New York",
    country: "EEUU "
}, {
    city: "Tokio",
    country: "Japon "
}, {
    city: "Paris",
    country: "Francia "
}]

const asd = [
    {
        temperature: 30,
        state: "sunny"
    },{
        temperature: 30,
        state: "sunny"
    },{
        temperature: 30,
        state: "sunny"
    },{
        temperature: 30,
        state: "sunny"
    },{
        temperature: 30,
        state: "sunny"
    },{
        temperature: 30,
        state: "sunny"
    }
]

function aler(mens) {

}

export const CityListExample = () => {
    return <CityList cities={cities} Weather={asd} onCLickCity={aler("Click en City")} />
}

