/* eslint-disable no-undef */
import React, { useState, useEffect } from 'react'
import PropTypes from 'prop-types'
import CityInfo from '../CityInfo/CityInfo'
import Weather from '../Weather/Weather'
import Grid from '@material-ui/core/Grid'
import List from '@material-ui/core/List'
import ListItem from '@material-ui/core/ListItem'
import axios from 'axios'

const renderCityAndCountry = eventOnClickCity => (CityAndCountry, weather) => {
    const { city, country } = CityAndCountry
    console.log("esto es lo que trae weather")
    console.log(weather);
    // const { temperature, state } = Weather
    return (
        <ListItem button key={CityAndCountry} onClick={eventOnClickCity}>
            <Grid container justify="center" alignItems="center">
                <Grid item md={8} xs={12}>
                    <CityInfo city={city} country={country} />
                </Grid>
                <Grid item md={4} xs={12}>
                    {
                        weather?
                        <Weather temperature={weather.temperature} state={weather.state} />
                        :console.log(weather)
                    }
                    
                </Grid>
            </Grid>
        </ListItem>
    )
}

const CityList = (props) => {

    const { cities, onCLickCity } = props
    const [allWeather, setAllWeather] = useState({})


    useEffect(() => {
        const setWeather=(city,country,countryCode)=>{
        const appid = '03e3eb2b603b7779f672f2139e2d1c7f'
        const url = `https://api.openweathermap.org/data/2.5/weather?q=${city},${countryCode}&appid=${appid}`

        axios.get(url).then(response => {
            const { data } = response
            response ? console.log(response) : console.log("valio maiz carnalito");
            const temperature = data.main.temp
            const state = "cloudy"
            const propName = `${city}-${country}`
            const propValue = {temperature,state }
            console.log(temperature);
            setAllWeather(allWeather => {
                const result = { ...allWeather, [propName]: propValue }
                console.log(result)
                return result
            })
        })
    }
        cities.forEach(({ city, country, countryCode }) => {
            setWeather(city, country, countryCode)
        })
    }, [cities])

    // const Weather = {
    //     temperature: 30,
    //     state: "sunny"
    // }
    return (
        <>
            {/* <h1>No esta retornando nada</h1> */}
            <List>{
                cities.map((CityAndCountry) => {
                    return renderCityAndCountry(onCLickCity)(CityAndCountry,
                        allWeather[`${CityAndCountry.cities}-${CityAndCountry.country}`])
                })
            }
            </List>
        </>
    )
}

CityList.propTypes = {
    cities: PropTypes.arrayOf(
        PropTypes.shape({
            city: PropTypes.string.isRequired,
            country: PropTypes.string.isRequired,
            countryCode: PropTypes.string.isRequired
        })
    ),
    onCLickCity: PropTypes.func
}

export default CityList




