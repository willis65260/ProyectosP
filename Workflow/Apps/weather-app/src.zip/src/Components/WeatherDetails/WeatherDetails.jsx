import React from 'react'
import PropTypes from 'prop-types'
import { Grid, Typography } from '@material-ui/core'
import Weather from '../Weather/Weather'
import { IconContext } from 'react-icons'
import IconState, { validValues } from '../IconState/IconState'


const WeatherDetails = props => {
    const { humedad, viento } = props
    return (
        <>
            <Grid container item direction="column" justify="center" alignItems="center" spacing={1}>
                <Grid item>
                    <Typography>
                        Humedad: {humedad} %
                    </Typography>
                </Grid>
                <Grid item>
                    <Typography>
                        Viento: {viento} km/hr
                    </Typography>
                </Grid>
            </Grid>
        </>
    )
}

WeatherDetails.propTypes = {
    humedad: PropTypes.number.isRequired,
    viento: PropTypes.number.isRequired
}

export default WeatherDetails
