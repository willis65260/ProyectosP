import React from 'react'
import PropTypes from 'prop-types'
import Typography from '@material-ui/core/Typography'
import { WiCloud, WiDayCloudy, WiDayFog, WiDaySunny, WiRain } from "react-icons/wi";
import { IconContext } from 'react-icons'

const stateByName = {
    'cloud': <WiCloud/>,
    'cloudy': <WiDayCloudy/>,
    'fog': <WiDayFog/>,
    'sunny': <WiDaySunny/>,
    'rainy': <WiRain/>
}

const renderState = state => {
    return stateByName[state]
}

const IconState = props => {
    const { state } = props
    return (
        <>
            {renderState(state)}
        </>
    )
}

export const validValues=["cloud","cloudy","fog","sunny","rain"]


IconState.propTypes = {
    state: PropTypes.oneOf(validValues).isRequired
}

export default IconState
