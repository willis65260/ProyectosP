import React from 'react'

import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
import { useHistory } from 'react-router-dom'
import CityList from '../Components/CityList/CityList'
import AppFrame from '../Components/AppFrame/AppFrame'
import { Paper } from '@material-ui/core'

const cities = [{
    city: "distrito federal",
    country: "Mexico",
    countryCode: "MX"
}, {
    city: "bogota",
    country: "Colombia",
    countryCode: "CO"
}, {
    city: "Madrid",
    country: "España",
    countryCode: "ES"
}, {
    city: "Guadalajara",
    country: "Mexico",
    countryCode: "MX"
}, {
    city: "Tokio",
    country: "Japon",
    countryCode: "JP"
}, {
    city: "Paris",
    country: "Francia",
    countryCode: "FR"
}]

const Welcome = props => {
    const history = useHistory();
    const onClickHandler = () => {
        history.push('/city')
    }
    return (
        <>
            <AppFrame>
               
                {/* <button onClick={onClickHandler}>Ir a CityPage</button> */}
            </AppFrame>
                <br />
                <Paper>
                    <CityList cities={cities} onCLickCity={onClickHandler} />
                </Paper>
        </>
    )
}



export default Welcome
