import React from 'react'
import PropTypes from 'prop-types'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'

const PageNotFound = props => {
    return (
        <>
            <Link to='/main'> regresar a Main </Link>
            <h2>Eror 404</h2>
        </>
    )
}

PageNotFound.propTypes = {

}

export default PageNotFound
