import React from 'react'
import PropTypes from 'prop-types'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'
import { Grid } from '@material-ui/core'
import CityInfo from '../Components/CityInfo/CityInfo'
import Weather from '../Components/Weather/Weather'
import WeatherDetails from '../Components/WeatherDetails/WeatherDetails'
import ForecastChart from '../Components/ForecastChart/ForecastChart'
import Forecast from '../Components/Forecast/Forecast'
import AppFrame from '../Components/AppFrame/AppFrame'

const city = 'Chupapimuñeño'
const country = 'Mexico'
const state = 'rainy'
const temperature = '17'
const humidity = 20
const wind = 10
const data = [
    {
        "dayHour": "Jue 18",
        "min": 14,
        "max": 22
    }, {
        "dayHour": "Vie 06",
        "min": 18,
        "max": 27
    }, {
        "dayHour": "Vie 12",
        "min": 18,
        "max": 28
    }, {
        "dayHour": "Vie 18",
        "min": 18,
        "max": 25
    }, {
        "dayHour": "Sab 06",
        "min": 15,
        "max": 22
    }, {
        "dayHour": "Sab 12",
        "min": 12,
        "max": 19
    },
]

const forecastItemList = [
    { weekDay: "Lunes", hour: 18, state: "sunny", temperature: 17 },
    { weekDay: "Martes", hour: 18, state: "cloud", temperature: 17 },
    { weekDay: "Miercoles", hour: 18, state: "cloudy", temperature: 17 },
    { weekDay: "Jueves", hour: 18, state: "rainy", temperature: 17 },
    { weekDay: "Viernes", hour: 18, state: "sunny", temperature: 17 },
    { weekDay: "Sabado", hour: 18, state: "cloud", temperature: 17 },
    { weekDay: "Domingo", hour: 18, state: "rainy", temperature: 17 }
]

const Welcome = props => {
    return (
        <Grid container justify='space-around' direction='column' spacing={16}>
            <br />
            {/* <Link to='/main'> regresar a Main </Link>
            <h2>city</h2> */}
            <Grid container item xs={12} justify="center" alignItems="center" spacing={1}>
                <CityInfo city={city} country={country} />
            </Grid>
            <Grid container item xs={12} justify="center">

                <Weather state={state} temperature={temperature} />
                <WeatherDetails humedad={humidity} viento={wind} />

            </Grid>
            <Grid item>
                <ForecastChart data={data} />
            </Grid>
            <Grid item>
                <Forecast forecastItemList={forecastItemList} />
            </Grid>
        </Grid>
    )
}

Welcome.propTypes = {

}

export default Welcome
