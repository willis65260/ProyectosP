import React from 'react'
import PropTypes from 'prop-types'
import { BrowserRouter as Router, Switch, Route, Link } from 'react-router-dom'

const Welcome = props => {
    return (
        <>
            <h1>Welcome</h1>
            <Link to='/main'> Ir a Main </Link>
        </>
    )
}

Welcome.propTypes = {

}

export default Welcome
