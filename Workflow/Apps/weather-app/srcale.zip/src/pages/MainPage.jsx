import React from 'react';
import {useHistory} from 'react-router-dom'
import CityList from '../Components/CityList/CityList'
import AppFrame from '../Components/AppFrame/AppFrame'
import Paper from '@material-ui/core/Paper'
const MainPage = () => {

    const cities=[
        {city:"Morelia", country:"Mexico", countryCode:"MX"},
        {city:"Bogota", country:"Colombia", countryCode:"CO"},
        {city:"Madrid", country:"Espana", countryCode:"ES"},
        {city:"Tokio", country:"Japon", countryCode:"JP"},
        {city:"Paris", country:"Francia", countryCode:"FR"}
    ]


const History = useHistory()
const onCLickHandler = () => {
    History.push('/city')
}

    return (
        <AppFrame>
            <Paper elevation={3}> 
             <CityList cities={cities} onClickCity={onCLickHandler} />
             </Paper>
        </AppFrame>
    );
};


export default MainPage;