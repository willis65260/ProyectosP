import React from 'react'
import CityInfo from './CityInfo'

export default {
    title: "CitiInfo",
    component: CityInfo
}

export const CiudadEjemplo = () =><CityInfo city={"Guadalajara"} country={"Mexico"}></CityInfo>