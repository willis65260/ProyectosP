suma (a,b) (c,d) = (a+c, b+d)
producto (a,b) (c,d) = (a*c-b*d, a*d+b*c)
conjugado (a,b) = (a,-b)