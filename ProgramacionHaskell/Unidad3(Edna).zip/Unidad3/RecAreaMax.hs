mayorRectangulo (a,b) (c,d) | a*b >= c*d = (a,b)
                            | otherwise = (c,d)