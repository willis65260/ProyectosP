divisionSegura _ 0 = 9999
divisionSegura x y = x/y