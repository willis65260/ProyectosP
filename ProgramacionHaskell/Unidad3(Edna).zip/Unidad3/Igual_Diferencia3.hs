tresIguales x y z = x == y && y == z
tresDiferentes x y z = x /= y && x /= z && y /= z