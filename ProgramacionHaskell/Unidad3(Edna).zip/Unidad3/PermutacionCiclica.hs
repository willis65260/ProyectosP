ciclo [] = [] 
ciclo x = last x : init x