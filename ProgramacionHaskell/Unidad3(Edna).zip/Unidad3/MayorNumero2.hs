numeroMayor x y = a*10 + b
    where a = max x y
          b = min x y