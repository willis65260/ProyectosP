tresIguales x y z = x == y && y == z
cuatroIguales x y z u = x == y && tresIguales y z u