package Unidad2.Unidad2;

import java.awt.*;

class punto2D2
{
	double x,y;
	public punto2D2(double a, double b)
	{
		x=a;y=b;
	}
}

public class Figura2D2   
{
	punto2D2 figura[];
	punto2D2 figMapeo[];
	
	public Figura2D2()
	{
							   
		figura=new punto2D2[]{};
		
		figMapeo=new punto2D2[figura.length];
		for(int i=0;i<figMapeo.length;i++)
		
			figMapeo[i]=new punto2D2(0, 0);
		
			
	}
	
	public void DibujarVecPuntos(Graphics g)
	{
		g.setColor(Color.BLACK);
		for(int p1=1,p2=2;p1<figura.length-1;p1+=1,p2+=1)
		{
			g.drawLine((int)figura[p1].x,(int)figura[p1].y,(int)figura[p2].x,(int)figura[p2].y);
		}
	}
	
	public void escalaeO(double esc)
	{
		for(int i=0;i<figura.length;i++)
		{
			figura[i].x=esc*figura[i].x;
			figura[i].y=esc*figura[i].y;
		}
	}
	
	public void escalarPunto(double esc)
	{
		int tx=(int)figura[0].x;
		int ty=(int)figura[0].y;
		TraslacionO(-tx,-ty);
		escalaeO(esc);
		TraslacionO(tx,ty);
	}
	
	public void escalarPuntoH(double esc)
	{
		int Tx=(int)figura[0].x;
		int Ty=(int)figura[0].y;
		
		for(int i=0;i<figura.length;i++)
		{
			figura[i].x=figura[i].x*esc-Tx*esc+Tx;
			figura[i].y=figura[i].y*esc-Ty*esc+Ty;

		}
		
	}
	
	public void deformarO(double defx,double defy)
	{
		for(int i=0;i<figura.length;i++)
		{
			double cx=figura[i].x;
			figura[i].x=figura[i].x+defx*figura[i].y;
			figura[i].y=defx*cx+figura[i].y;
		}
	}
	
	public void deformarPunto(double defx,double defy)
	{
		int tx=(int)figura[0].x;
		int ty=(int)figura[0].y;
		TraslacionO(-tx,-ty);
		deformarO(defx, defy);
		TraslacionO(tx, ty);
	}
	
	public void deformarPuntoH(double A,double B)
	{
		int tx=(int)figura[0].x;
		int ty=(int)figura[0].y;
		for(int i=0;i<figura.length;i++)
		{
			double x=figura[i].x;
			figura[i].x=x+A*figura[i].y-A*ty;
			figura[i].y=x*B+figura[i].y-tx*B;
		}
	}
	
	public void Restaurar()
	{
		figura=new punto2D2[]{
				 new punto2D2(350,400),
				 new punto2D2(300, 400),new punto2D2(350, 400),
				 new punto2D2(350, 500),new punto2D2(400, 500),
				 new punto2D2(400, 300),new punto2D2(350, 300),
				 new punto2D2(300, 400)};

	}
	
	public void rotacionSentPunto(int ang)
	{
		int tx=(int)figura[0].x;
		int ty=(int)figura[0].y;
		TraslacionO(-tx,-ty);
		RotacionSenO(ang);
		TraslacionO(tx, ty);
	}
	
	public void rotacionConPunto(int ang)
	{
		int tx=(int)figura[0].x;
		int ty=(int)figura[0].y;
		TraslacionO(-tx,-ty);
		RotacionConO(ang);
		TraslacionO(tx, ty);
	}
	
	
	
	public void RotacionSenO(int ang)
	{
		
		double angRad=Math.toRadians(ang);
		double seno=Math.sin(angRad);
		double coseno=Math.cos(angRad);
		
		for(int i=0;i<figura.length;i++)
		{
			double x=figura[i].x;
			double y=figura[i].y;
			figura[i].x=x*coseno-y*seno;
			figura[i].y=x*seno+y*coseno;
		}
	}
	
	public void RotacionConO(int ang)
	{
		
		double angRad=Math.toRadians(ang);
		double seno=Math.sin(angRad);
		double coseno=Math.cos(angRad);
		
		for(int i=0;i<figura.length;i++)
		{
			double x=figura[i].x;
			double y=figura[i].y;
			figura[i].x=x*coseno+y*seno;
			figura[i].y=-x*seno+y*coseno;
		}
	}
	
	public void RotacionConPuntoH(int ang)
	{
		int tx=(int)figura[0].x;
		int ty=(int)figura[0].y;
		double angRad=Math.toRadians(ang);
		double seno=Math.sin(angRad);
		double coseno=Math.cos(angRad);
		for(int i=0;i<figura.length;i++)
		{
			double x=figura[i].x;
			double y=figura[i].y;
			figura[i].x=x*coseno+y*seno-tx*coseno-ty*seno+tx;
			figura[i].y=-x*seno+y*coseno+tx*seno-ty*coseno+ty;

		}
	}
	public void RotacionSenPuntoH(int ang)
	{
		int tx=(int)figura[0].x;
		int ty=(int)figura[0].y;
		double angRad=Math.toRadians(ang);
		double seno=Math.sin(angRad);
		double coseno=Math.cos(angRad);
		for(int i=0;i<figura.length;i++)
		{
			double x=figura[i].x;
			double y=figura[i].y;
			figura[i].x=x*coseno-y*seno-tx*coseno+ty*seno+tx;
			figura[i].y=x*seno+y*coseno-tx*seno-ty*coseno+ty;

		}
	}
	
	public void TraslacionO(int tx,int ty)
	{
		for(int i=0;i<figura.length;i++)
		{
			figura[i].x+=tx;
			figura[i].y+=ty;
		}
	}
	
	public void Refleccion(int rfx,int rfy)
	{
		for(int i=0;i<figura.length;i++)
		{
			figura[i].x=rfx*figura[i].x;
			figura[i].y=rfy*figura[i].y;
		}
	}
	
	public void RefleccionPunto(int rfx,int rfy)
	{
		int tx=(int)figura[0].x;
		int ty=(int)figura[0].y;
		TraslacionO(-tx,-ty);
		Refleccion(rfx, rfy);
		TraslacionO(tx, ty);
	}
	
	public void refleccionPuntoH(double Rx,double Ry)
	{
		int Tx=(int)figura[0].x;
		int Ty=(int)figura[0].y;
		
		for(int i=0;i<figura.length;i++)
		{
			figura[i].x=figura[i].x*Rx-Tx*Rx+Tx;
			figura[i].y=figura[i].y*Ry-Ty*Ry+Ty;

		}
		
	}
	
	public void mapeoVentana(int xvmax,int xvmin,int yvmax,int yvmin,int xwmax,int ywmax,Graphics g)
	{
		double sx=((double)(xvmax-xvmin)/(double)(xwmax-0));
		double sy=((double)(yvmax-yvmin)/(double)(ywmax-0));

		for(int i=0;i<figura.length;i++)
		{
			figMapeo[i].x=figura[i].x*sx;
			figMapeo[i].y=figura[i].y*sy;
			figMapeo[i].x+=xvmin;
			figMapeo[i].y+=yvmin;

		}
		
		g.setColor(Color.WHITE);
		for(int p1=1,p2=2;p1<figMapeo.length-1;p1+=1,p2+=1)
		{
			g.drawLine((int)figMapeo[p1].x,(int)figMapeo[p1].y,(int)figMapeo[p2].x,(int)figMapeo[p2].y);
		}

	}
	
}
